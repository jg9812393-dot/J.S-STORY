/* ========================================
   CONFIGURACIÓN
======================================== */

// Número de WhatsApp de la tienda llega al vendedor
const numeroWhatsApp = "50671237124";


/* ========================================
   BOTÓN DE Whatsapp
======================================== */

function comprarProducto(nombreProducto, precioProducto) {

    // Mensaje que recibirá WhatsApp
    const mensaje =
        `Hola 👋, estoy interesado en este producto:

🛍️ Producto: ${nombreProducto}
💰 Precio: ${precioProducto}

¿Está disponible?`;


    // Convertir el mensaje para utilizarlo dentro de una URL
    const mensajeCodificado = encodeURIComponent(mensaje);


    // Crear el enlace de WhatsApp
    const enlaceWhatsApp =
        `https://wa.me/${numeroWhatsApp}?text=${mensajeCodificado}`;


    // Abrir WhatsApp en una nueva pestaña
    window.open(enlaceWhatsApp, "_blank");
}


/* ========================================
   FILTRAR PRODUCTOS
======================================== */

function filtrarProductos(categoria) {

    const productos =
        document.querySelectorAll(".producto");


    productos.forEach(function(producto) {

        const categoriaProducto =
            producto.getAttribute("data-categoria");


        if (
            categoria === "todos" ||
            categoriaProducto === categoria
        ) {

            producto.classList.remove("oculto");

        } else {

            producto.classList.add("oculto");

        }

    });

}


/* ========================================
   BUSCADOR
======================================== */

const buscador =
    document.getElementById("buscador");


buscador.addEventListener("input", function() {

    const textoBusqueda =
        buscador.value.toLowerCase().trim();


    const productos =
        document.querySelectorAll(".producto");


    let productosEncontrados = 0;


    productos.forEach(function(producto) {

        // Obtener información del producto
        const nombre =
            producto.querySelector("h3")
            .textContent
            .toLowerCase();


        const descripcion =
            producto.querySelector(".descripcion")
            .textContent
            .toLowerCase();


        const categoria =
            producto.querySelector(".categoria")
            .textContent
            .toLowerCase();


        /*
        Comprobar si el texto escrito
        coincide con el producto
        */
        if (
            nombre.includes(textoBusqueda) ||
            descripcion.includes(textoBusqueda) ||
            categoria.includes(textoBusqueda)
        ) {

            producto.classList.remove("oculto");

            productosEncontrados++;

        } else {

            producto.classList.add("oculto");

        }

    });


    mostrarMensajeSinProductos(productosEncontrados);

});


/* ========================================
   MENSAJE CUANDO NO HAY PRODUCTOS
======================================== */

function mostrarMensajeSinProductos(cantidad) {

    const contenedor =
        document.querySelector(".contenedor-productos");


    let mensajeExistente =
        document.querySelector(".sin-productos");


    if (cantidad === 0) {

        if (!mensajeExistente) {

            mensajeExistente =
                document.createElement("div");

            mensajeExistente.classList.add(
                "sin-productos"
            );

            mensajeExistente.innerHTML = `
                <h3>😕 No encontramos productos</h3>
                <p>
                    Intenta buscar otro producto.
                </p>
            `;

            contenedor.appendChild(mensajeExistente);
        }

    } else {

        if (mensajeExistente) {

            mensajeExistente.remove();

        }

    }

}


/* ========================================
   LIMPIAR BUSCADOR AL USAR FILTROS
======================================== */

function limpiarBuscador() {

    buscador.value = "";

}


/*
Sobrescribimos la función de filtros
para que también limpie el buscador.
*/

const filtrosOriginales =
    window.filtrarProductos;


window.filtrarProductos = function(categoria) {

    limpiarBuscador();


    const productos =
        document.querySelectorAll(".producto");


    productos.forEach(function(producto) {

        const categoriaProducto =
            producto.getAttribute("data-categoria");


        if (
            categoria === "todos" ||
            categoriaProducto === categoria
        ) {

            producto.classList.remove("oculto");

        } else {

            producto.classList.add("oculto");

        }

    });


    // Eliminar mensaje de "no hay productos"
    const mensaje =
        document.querySelector(".sin-productos");


    if (mensaje) {
        mensaje.remove();
    }

};


/* ========================================
   ANIMACIÓN AL CARGAR LA PÁGINA
======================================== */

document.addEventListener("DOMContentLoaded", function() {

    const productos =
        document.querySelectorAll(".producto");


    productos.forEach(function(producto, index) {

        producto.style.opacity = "0";

        producto.style.transform = "translateY(20px)";


        setTimeout(function() {

            producto.style.transition =
                "opacity 0.5s ease, transform 0.5s ease";

            producto.style.opacity = "1";

            producto.style.transform =
                "translateY(0)";

        }, index * 100);

    });

});